using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Microsoft.Win32;
using System.Web.Script.Serialization;

namespace RevitExporterAddin.Services
{
    public class AuthService : IAuthService
    {
        private const string API_BASE_URL = "http://195.133.25.152:7777";
        private const string TOKEN_REGISTRY_KEY = @"SOFTWARE\CivilX\DataViewer";
        private const string TOKEN_VALUE_NAME = "AuthToken";
        
        private readonly HttpClient _httpClient;
        private readonly string _tokenFilePath;

        public AuthService()
        {
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
            
            // Путь для сохранения токена в зашифрованном виде
            var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var civilXPath = Path.Combine(appDataPath, "CivilX", "DataViewer");
            Directory.CreateDirectory(civilXPath);
            _tokenFilePath = Path.Combine(civilXPath, "auth_token.dat");
        }

        public async Task<AuthResult> LoginAsync(string email, string password)
        {
            try
            {
                var requestData = new
                {
                    email = email,
                    password = password
                };

                var json = new JavaScriptSerializer().Serialize(requestData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var url = $"{API_BASE_URL}/taskflow.app/auth-api.php/api/login";
                System.Diagnostics.Debug.WriteLine($"Login URL: {url}");
                
                var response = await _httpClient.PostAsync(url, content);
                var responseContent = await response.Content.ReadAsStringAsync();
                
                System.Diagnostics.Debug.WriteLine($"Response Status: {response.StatusCode}");
                System.Diagnostics.Debug.WriteLine($"Response Content: {responseContent}");

                if (response.IsSuccessStatusCode)
                {
                    var result = new JavaScriptSerializer().Deserialize<LoginResponse>(responseContent);
                    
                    if (!string.IsNullOrEmpty(result.token) && result.user != null)
                    {
                        return new AuthResult
                        {
                            Success = true,
                            Token = result.token,
                            User = result.user
                        };
                    }
                    else
                    {
                        return new AuthResult
                        {
                            Success = false,
                            ErrorMessage = result.error ?? "Ошибка авторизации"
                        };
                    }
                }
                else
                {
                    return new AuthResult
                    {
                        Success = false,
                        ErrorMessage = $"Ошибка сервера: {response.StatusCode}\nURL: {url}\nОтвет: {responseContent}"
                    };
                }
            }
            catch (Exception ex)
            {
                var errorDetails = $"Ошибка подключения: {ex.Message}\n";
                errorDetails += $"Тип ошибки: {ex.GetType().Name}\n";
                errorDetails += $"Внутренняя ошибка: {ex.InnerException?.Message ?? "Нет"}\n";
                errorDetails += $"Детали: {ex.StackTrace}";
                
                return new AuthResult
                {
                    Success = false,
                    ErrorMessage = errorDetails
                };
            }
        }

        public async Task<AuthResult> RegisterAsync(string userType, string name, string login, string email, string password)
        {
            try
            {
                var requestData = new
                {
                    user_type = userType,
                    name = name,
                    login = login,
                    email = email,
                    password = password
                };

                var json = new JavaScriptSerializer().Serialize(requestData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync($"{API_BASE_URL}/taskflow.app/auth-api.php/api/register", content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var result = new JavaScriptSerializer().Deserialize<RegisterResponse>(responseContent);
                    
                    if (!string.IsNullOrEmpty(result.token) && result.user != null)
                    {
                        return new AuthResult
                        {
                            Success = true,
                            Token = result.token,
                            User = result.user
                        };
                    }
                    else
                    {
                        return new AuthResult
                        {
                            Success = false,
                            ErrorMessage = result.error ?? "Ошибка регистрации"
                        };
                    }
                }
                else
                {
                    return new AuthResult
                    {
                        Success = false,
                        ErrorMessage = $"Ошибка сервера: {response.StatusCode}"
                    };
                }
            }
            catch (Exception ex)
            {
                return new AuthResult
                {
                    Success = false,
                    ErrorMessage = $"Ошибка подключения: {ex.Message}"
                };
            }
        }

        public async Task<UserInfo> GetUserInfoAsync(string token)
        {
            try
            {
                _httpClient.DefaultRequestHeaders.Authorization = 
                    new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.GetAsync($"{API_BASE_URL}/taskflow.app/auth-api.php/api/me");
                var responseContent = await response.Content.ReadAsStringAsync();

                if (response.IsSuccessStatusCode)
                {
                    var result = new JavaScriptSerializer().Deserialize<UserInfoResponse>(responseContent);
                    
                    if (result.user != null)
                    {
                        return result.user;
                    }
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

        public async Task<bool> ValidateTokenAsync(string token)
        {
            try
            {
                var userInfo = await GetUserInfoAsync(token);
                return userInfo != null;
            }
            catch
            {
                return false;
            }
        }

        public string GetStoredToken()
        {
            try
            {
                // Сначала пробуем получить из реестра
                using (var key = Registry.CurrentUser.OpenSubKey(TOKEN_REGISTRY_KEY))
                {
                    if (key != null)
                    {
                        var encryptedToken = key.GetValue(TOKEN_VALUE_NAME) as string;
                        if (!string.IsNullOrEmpty(encryptedToken))
                        {
                            return DecryptToken(encryptedToken);
                        }
                    }
                }

                // Если в реестре нет, пробуем файл
                if (File.Exists(_tokenFilePath))
                {
                    var encryptedToken = File.ReadAllText(_tokenFilePath);
                    return DecryptToken(encryptedToken);
                }

                return null;
            }
            catch
            {
                return null;
            }
        }

        public void SaveToken(string token)
        {
            try
            {
                var encryptedToken = EncryptToken(token);

                // Сохраняем в реестр
                using (var key = Registry.CurrentUser.CreateSubKey(TOKEN_REGISTRY_KEY))
                {
                    key?.SetValue(TOKEN_VALUE_NAME, encryptedToken);
                }

                // Дублируем в файл для надежности
                File.WriteAllText(_tokenFilePath, encryptedToken);
            }
            catch
            {
                // Игнорируем ошибки сохранения
            }
        }

        public void ClearToken()
        {
            try
            {
                // Удаляем из реестра
                using (var key = Registry.CurrentUser.OpenSubKey(TOKEN_REGISTRY_KEY, true))
                {
                    key?.DeleteValue(TOKEN_VALUE_NAME, false);
                }

                // Удаляем файл
                if (File.Exists(_tokenFilePath))
                {
                    File.Delete(_tokenFilePath);
                }
            }
            catch
            {
                // Игнорируем ошибки удаления
            }
        }

        private string EncryptToken(string token)
        {
            try
            {
                var key = GetEncryptionKey();
                var data = Encoding.UTF8.GetBytes(token);
                
                using (var aes = Aes.Create())
                {
                    aes.Key = key;
                    aes.GenerateIV();
                    
                    using (var encryptor = aes.CreateEncryptor())
                    using (var ms = new MemoryStream())
                    {
                        ms.Write(aes.IV, 0, aes.IV.Length);
                        
                        using (var cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                        {
                            cs.Write(data, 0, data.Length);
                        }
                        
                        return Convert.ToBase64String(ms.ToArray());
                    }
                }
            }
            catch
            {
                return token; // Возвращаем незашифрованный токен в случае ошибки
            }
        }

        private string DecryptToken(string encryptedToken)
        {
            try
            {
                var key = GetEncryptionKey();
                var data = Convert.FromBase64String(encryptedToken);
                
                using (var aes = Aes.Create())
                {
                    aes.Key = key;
                    
                    var iv = new byte[16];
                    Array.Copy(data, 0, iv, 0, 16);
                    aes.IV = iv;
                    
                    using (var decryptor = aes.CreateDecryptor())
                    using (var ms = new MemoryStream(data, 16, data.Length - 16))
                    using (var cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    using (var reader = new StreamReader(cs))
                    {
                        return reader.ReadToEnd();
                    }
                }
            }
            catch
            {
                return encryptedToken; // Возвращаем зашифрованный токен в случае ошибки
            }
        }

        private byte[] GetEncryptionKey()
        {
            // Используем стабильный ключ на основе имени машины и пользователя
            var machineName = Environment.MachineName;
            var userName = Environment.UserName;
            var keyString = $"{machineName}_{userName}_CivilX_DataViewer_2024";
            
            using (var sha256 = SHA256.Create())
            {
                return sha256.ComputeHash(Encoding.UTF8.GetBytes(keyString));
            }
        }

        public void Dispose()
        {
            _httpClient?.Dispose();
        }
    }

    // Классы для десериализации API ответов
    public class LoginResponse
    {
        public string message { get; set; }
        public string token { get; set; }
        public UserInfo user { get; set; }
        public string error { get; set; }
    }

    public class RegisterResponse
    {
        public string message { get; set; }
        public string token { get; set; }
        public UserInfo user { get; set; }
        public string error { get; set; }
    }

    public class UserInfoResponse
    {
        public UserInfo user { get; set; }
        public string error { get; set; }
    }
}
