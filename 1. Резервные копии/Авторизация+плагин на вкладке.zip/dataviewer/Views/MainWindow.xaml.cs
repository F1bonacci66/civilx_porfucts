using System.Windows;
using RevitExporter.ViewModels;

namespace RevitExporter.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
