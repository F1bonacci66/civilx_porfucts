using System;

namespace CivilXAuthPlugin
{
    public class UserInfo
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public string UserType { get; set; }
        public string CompanyName { get; set; }
        public string Phone { get; set; }
        public DateTime? CreatedAt { get; set; }
    }

    public class UserProduct
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public string product_name { get; set; }
        public string plan_type { get; set; }
        public string purchase_status { get; set; }
        public string activation_status { get; set; }
        public DateTime? purchase_date { get; set; }
        public DateTime? activation_date { get; set; }
        public DateTime? expires_at { get; set; }
        public DateTime? cancelled_at { get; set; }
        public string position_login { get; set; }
    }

    public class UserProductsResponse
    {
        public System.Collections.Generic.List<UserProduct> products { get; set; }
        public string error { get; set; }
    }

    public class AuthResult
    {
        public bool Success { get; set; }
        public string Token { get; set; }
        public string ErrorMessage { get; set; }
        public UserInfo User { get; set; }
    }
}
