using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Web.Script.Serialization;
using CivilXAuthPlugin.Services;

namespace CivilXAuthPlugin
{
    public partial class AuthWindow : Window
    {
        private readonly IAuthService _authService;
        private UserInfo _currentUser;
        private UserProduct _activatedProduct;

        public AuthWindow()
        {
            InitializeComponent();
            _authService = new AuthService();
            _activatedProduct = null;
            
            // Загружаем активированный продукт
            LoadActivatedProduct();
            
            // Проверяем авторизацию при запуске
            CheckAuthentication();
        }

        private async void CheckAuthentication()
        {
            try
            {
                var token = _authService.GetStoredToken();
                if (!string.IsNullOrEmpty(token))
                {
                    var isValid = await _authService.ValidateTokenAsync(token);
                    if (isValid)
                    {
                        _currentUser = await _authService.GetUserInfoAsync(token);
                        ShowMainScreen();
                        UpdateUserStatusIndicator();
                        return;
                    }
                    else
                    {
                        _authService.ClearToken();
                    }
                }
                
                ShowAuthScreen();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка при проверке авторизации: {ex.Message}");
                ShowAuthScreen();
            }
        }

        private void ShowAuthScreen()
        {
            AuthScreen.Visibility = Visibility.Visible;
            MainScreen.Visibility = Visibility.Collapsed;
        }

        private void ShowMainScreen()
        {
            AuthScreen.Visibility = Visibility.Collapsed;
            MainScreen.Visibility = Visibility.Visible;
            ShowUserProfileScreen();
        }

        private void LoginTabButton_Click(object sender, RoutedEventArgs e)
        {
            LoginForm.Visibility = Visibility.Visible;
            RegisterForm.Visibility = Visibility.Collapsed;
            LoginTabButton.Background = new SolidColorBrush(Color.FromRgb(59, 130, 246));
            RegisterTabButton.Background = new SolidColorBrush(Color.FromRgb(75, 85, 99));
        }

        private void RegisterTabButton_Click(object sender, RoutedEventArgs e)
        {
            LoginForm.Visibility = Visibility.Collapsed;
            RegisterForm.Visibility = Visibility.Visible;
            RegisterTabButton.Background = new SolidColorBrush(Color.FromRgb(59, 130, 246));
            LoginTabButton.Background = new SolidColorBrush(Color.FromRgb(75, 85, 99));
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                HideMessages();
                
                var email = LoginEmail.Text;
                var password = LoginPassword.Password;

                if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
                {
                    ShowError("Пожалуйста, заполните все поля");
                    return;
                }

                var result = await _authService.LoginAsync(email, password);
                
                if (result.Success)
                {
                    _authService.SaveToken(result.Token);
                    _currentUser = result.User;
                    ShowMainScreen();
                    UpdateUserStatusIndicator();
                    ShowSuccess("Успешный вход в систему!");
                }
                else
                {
                    ShowError($"Ошибка авторизации: {result.ErrorMessage}");
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка входа: {ex.Message}");
            }
        }

        private async void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                HideMessages();
                
                var userType = RegisterUserType.Text;
                var name = RegisterUserName.Text;
                var login = RegisterLogin.Text;
                var email = RegisterEmail.Text;
                var password = RegisterPassword.Password;
                var passwordConfirm = RegisterPasswordConfirm.Password;

                if (string.IsNullOrEmpty(userType) || string.IsNullOrEmpty(name) || 
                    string.IsNullOrEmpty(login) || string.IsNullOrEmpty(email) || 
                    string.IsNullOrEmpty(password) || string.IsNullOrEmpty(passwordConfirm))
                {
                    ShowError("Пожалуйста, заполните все поля");
                    return;
                }

                if (password != passwordConfirm)
                {
                    ShowError("Пароли не совпадают");
                    return;
                }

                var result = await _authService.RegisterAsync(userType, name, login, email, password);
                
                if (result.Success)
                {
                    _authService.SaveToken(result.Token);
                    _currentUser = result.User;
                    ShowMainScreen();
                    UpdateUserStatusIndicator();
                    ShowSuccess("Регистрация прошла успешно!");
                }
                else
                {
                    ShowError($"Ошибка регистрации: {result.ErrorMessage}");
                }
            }
            catch (Exception ex)
            {
                ShowError($"Ошибка регистрации: {ex.Message}");
            }
        }

        private void ShowUserProfileScreen()
        {
            // Очищаем все элементы
            MainGrid.Children.Clear();
            
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(300) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(5) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            
            // Левая панель - Вкладки параметров
            var leftPanel = CreateUserProfileLeftPanel();
            Grid.SetColumn(leftPanel, 0);
            grid.Children.Add(leftPanel);
            
            // GridSplitter
            var splitter = new GridSplitter
            {
                Width = 5,
                Background = new SolidColorBrush(Color.FromRgb(233, 236, 239)),
                HorizontalAlignment = HorizontalAlignment.Stretch
            };
            Grid.SetColumn(splitter, 1);
            grid.Children.Add(splitter);
            
            // Правая панель - Настройки (изначально показываем авторизацию)
            var rightPanel = CreateUserProfileRightPanel("Авторизация");
            Grid.SetColumn(rightPanel, 2);
            grid.Children.Add(rightPanel);
            
            MainGrid.Children.Add(grid);
        }

        private Border CreateUserProfileLeftPanel()
        {
            var border = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(248, 249, 250))
            };

            var stackPanel = new StackPanel { Margin = new Thickness(30) };
            
            // Заголовок
            var title = new TextBlock
            {
                Text = "Профиль пользователя",
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 30),
                Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
            };
            stackPanel.Children.Add(title);
            
            // Подзаголовок
            var subtitle = new TextBlock
            {
                Text = "Настройки профиля:",
                FontSize = 14,
                Margin = new Thickness(0, 0, 0, 15),
                Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125))
            };
            stackPanel.Children.Add(subtitle);
            
            // Список вкладок
            var scrollViewer = new ScrollViewer
            {
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                MaxHeight = 400
            };
            var tabsList = new StackPanel();
            
            // Вкладка "Информация о пользователе"
            var infoTab = CreateTabButton("👤 Информация о пользователе", "Информация о пользователе");
            tabsList.Children.Add(infoTab);
            
            // Вкладка "Мои продукты"
            var productsTab = CreateTabButton("📦 Мои продукты", "Мои продукты");
            tabsList.Children.Add(productsTab);
            
            // Вкладка "Управление профилем"
            var profileTab = CreateTabButton("⚙️ Управление профилем", "Управление профилем");
            tabsList.Children.Add(profileTab);
            
            // Вкладка "Управление аккаунтом"
            var authTab = CreateTabButton("🔐 Управление аккаунтом", "Авторизация");
            tabsList.Children.Add(authTab);
            
            scrollViewer.Content = tabsList;
            stackPanel.Children.Add(scrollViewer);
            
            border.Child = stackPanel;
            return border;
        }

        private Button CreateTabButton(string content, string tabName)
        {
            var button = new Button
            {
                Content = content,
                FontSize = 14,
                Height = 45,
                Margin = new Thickness(0, 0, 0, 8),
                Background = new SolidColorBrush(Color.FromRgb(255, 255, 255)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(222, 226, 230)),
                BorderThickness = new Thickness(1),
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Padding = new Thickness(15, 0, 0, 0)
            };
            
            button.Click += (s, e) => {
                // Обновляем правую панель
                var grid = MainGrid.Children.OfType<Grid>().FirstOrDefault();
                if (grid != null)
                {
                    var rightPanel = grid.Children.OfType<Border>().LastOrDefault();
                    if (rightPanel != null)
                    {
                        var newRightPanel = CreateUserProfileRightPanel(tabName);
                        Grid.SetColumn(newRightPanel, 2);
                        grid.Children.Remove(rightPanel);
                        grid.Children.Add(newRightPanel);
                    }
                }
            };
            
            return button;
        }

        private Border CreateUserProfileRightPanel(string selectedTab)
        {
            var border = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(255, 255, 255)),
                Padding = new Thickness(40)
            };

            var stackPanel = new StackPanel();

            switch (selectedTab)
            {
                case "Информация о пользователе":
                    LoadUserInfo(stackPanel);
                    break;
                case "Мои продукты":
                    LoadUserProducts(stackPanel);
                    break;
                case "Управление профилем":
                    LoadProfileEditForm(stackPanel);
                    break;
                case "Авторизация":
                    LoadAuthManagement(stackPanel);
                    break;
            }

            border.Child = stackPanel;
            return border;
        }

        private async void LoadUserInfo(StackPanel parentPanel)
        {
            var title = new TextBlock
            {
                Text = "Информация о пользователе",
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 30),
                Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
            };
            parentPanel.Children.Add(title);

            try
            {
                var token = _authService.GetStoredToken();
                if (!string.IsNullOrEmpty(token))
                {
                    var userInfo = await _authService.GetUserInfoAsync(token);
                    if (userInfo != null)
                    {
                        AddInfoField(parentPanel, "Имя", userInfo.Name ?? "Не указано");
                        AddInfoField(parentPanel, "Логин", userInfo.Login ?? "Не указано");
                        AddInfoField(parentPanel, "Email", userInfo.Email ?? "Не указано");
                        AddInfoField(parentPanel, "Тип пользователя", GetUserTypeDisplay(userInfo.UserType));
                        AddInfoField(parentPanel, "Компания", userInfo.CompanyName ?? "Не указано");
                        AddInfoField(parentPanel, "Телефон", userInfo.Phone ?? "Не указано");
                        AddInfoField(parentPanel, "Дата регистрации", userInfo.CreatedAt?.ToString("dd.MM.yyyy HH:mm") ?? "Не указано");
                    }
                }
            }
            catch (Exception ex)
            {
                var errorText = new TextBlock
                {
                    Text = $"Ошибка загрузки информации: {ex.Message}",
                    Foreground = new SolidColorBrush(Color.FromRgb(220, 53, 69)),
                    Margin = new Thickness(0, 20, 0, 0)
                };
                parentPanel.Children.Add(errorText);
            }
        }

        private void AddInfoField(StackPanel parent, string label, string value)
        {
            var fieldPanel = new StackPanel { Margin = new Thickness(0, 0, 0, 20) };
            
            var labelText = new TextBlock
            {
                Text = label,
                FontWeight = FontWeights.SemiBold,
                FontSize = 14,
                Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125)),
                Margin = new Thickness(0, 0, 0, 5)
            };
            fieldPanel.Children.Add(labelText);
            
            var valueText = new TextBlock
            {
                Text = value,
                FontSize = 16,
                Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
            };
            fieldPanel.Children.Add(valueText);
            
            parent.Children.Add(fieldPanel);
        }

        private string GetUserTypeDisplay(string userType)
        {
            switch (userType?.ToLower())
            {
                case "user":
                    return "Пользователь";
                case "organization":
                    return "Организация";
                default:
                    return userType ?? "Не указано";
            }
        }

        private async void LoadUserProducts(StackPanel parentPanel)
        {
            var title = new TextBlock
            {
                Text = "Мои продукты",
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 30),
                Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
            };
            parentPanel.Children.Add(title);

            try
            {
                var token = _authService.GetStoredToken();
                if (!string.IsNullOrEmpty(token))
                {
                    var products = await GetUserProductsAsync(token);
                    if (products != null && products.Any())
                    {
                        CreateProductsTable(parentPanel, products);
                    }
                    else
                    {
                        var noProductsText = new TextBlock
                        {
                            Text = "У вас пока нет купленных продуктов",
                            FontSize = 16,
                            Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125)),
                            Margin = new Thickness(0, 20, 0, 0)
                        };
                        parentPanel.Children.Add(noProductsText);
                    }
                }
                
                // Добавляем блок состояния подписки
                CreateSubscriptionStatusBlock(parentPanel);
            }
            catch (Exception ex)
            {
                var errorText = new TextBlock
                {
                    Text = $"Ошибка загрузки продуктов: {ex.Message}",
                    Foreground = new SolidColorBrush(Color.FromRgb(220, 53, 69)),
                    Margin = new Thickness(0, 20, 0, 0)
                };
                parentPanel.Children.Add(errorText);
            }
        }

        private async Task<List<UserProduct>> GetUserProductsAsync(string token)
        {
            try
            {
                using (var client = new System.Net.Http.HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = 
                        new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
                    
                    var response = await client.GetAsync("http://195.133.25.152:7777/taskflow.app/auth-api.php/api/user-products");
                    var responseContent = await response.Content.ReadAsStringAsync();
                    
                    if (response.IsSuccessStatusCode)
                    {
                        var result = new JavaScriptSerializer().Deserialize<UserProductsResponse>(responseContent);
                        return result.products ?? new List<UserProduct>();
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка получения продуктов: {ex.Message}");
            }
            
            return new List<UserProduct>();
        }

        private void CreateProductsTable(StackPanel parentPanel, List<UserProduct> products)
        {
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Заголовки
            var headers = new[] { "Продукт", "Статус", "Истекает", "Действие" };
            for (int i = 0; i < headers.Length; i++)
            {
                var header = new TextBlock
                {
                    Text = headers[i],
                    FontWeight = FontWeights.Bold,
                    FontSize = 14,
                    Margin = new Thickness(0, 0, 0, 10),
                    Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
                };
                Grid.SetRow(header, 0);
                Grid.SetColumn(header, i);
                grid.Children.Add(header);
            }

            // Данные
            for (int i = 0; i < products.Count; i++)
            {
                var product = products[i];
                var row = i + 1;

                // Продукт
                var productName = new TextBlock
                {
                    Text = GetProductDisplayName(product.product_name),
                    FontSize = 14,
                    Margin = new Thickness(0, 0, 0, 10),
                    Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
                };
                Grid.SetRow(productName, row);
                Grid.SetColumn(productName, 0);
                grid.Children.Add(productName);

                // Статус
                var status = new TextBlock
                {
                    Text = GetStatusDisplayText(product.activation_status),
                    FontSize = 14,
                    Margin = new Thickness(0, 0, 0, 10),
                    Foreground = new SolidColorBrush(GetStatusColor(product.activation_status))
                };
                Grid.SetRow(status, row);
                Grid.SetColumn(status, 1);
                grid.Children.Add(status);

                // Истекает
                var expires = new TextBlock
                {
                    Text = product.expires_at?.ToString("dd.MM.yyyy") ?? "—",
                    FontSize = 14,
                    Margin = new Thickness(0, 0, 0, 10),
                    Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125))
                };
                Grid.SetRow(expires, row);
                Grid.SetColumn(expires, 2);
                grid.Children.Add(expires);

                // Действие
                var actionButton = new Button
                {
                    Content = GetActionButtonText(product.activation_status),
                    FontSize = 12,
                    Height = 30,
                    Width = 100,
                    Margin = new Thickness(0, 0, 0, 10),
                    Background = new SolidColorBrush(GetActionButtonColor(product.activation_status)),
                    Foreground = Brushes.White,
                    BorderThickness = new Thickness(0)
                };
                actionButton.Click += (s, e) => HandleProductAction(product);
                Grid.SetRow(actionButton, row);
                Grid.SetColumn(actionButton, 3);
                grid.Children.Add(actionButton);
            }

            parentPanel.Children.Add(grid);
        }

        private string GetProductDisplayName(string productName)
        {
            switch (productName?.ToLower())
            {
                case "dataviewer":
                    return "DataViewer";
                default:
                    return productName ?? "Неизвестный продукт";
            }
        }

        private string GetStatusDisplayText(string status)
        {
            switch (status?.ToLower())
            {
                case "pending":
                    return "Ожидает активации";
                case "activated":
                    return "Активирован";
                case "expired":
                    return "Истек";
                default:
                    return status ?? "Неизвестно";
            }
        }

        private Color GetStatusColor(string status)
        {
            switch (status?.ToLower())
            {
                case "pending":
                    return Color.FromRgb(255, 193, 7);
                case "activated":
                    return Color.FromRgb(40, 167, 69);
                case "expired":
                    return Color.FromRgb(220, 53, 69);
                default:
                    return Color.FromRgb(108, 117, 125);
            }
        }

        private string GetActionButtonText(string status)
        {
            switch (status?.ToLower())
            {
                case "pending":
                    return "Активировать";
                case "activated":
                    return "Активирован";
                case "expired":
                    return "Продлить";
                default:
                    return "—";
            }
        }

        private Color GetActionButtonColor(string status)
        {
            switch (status?.ToLower())
            {
                case "pending":
                    return Color.FromRgb(40, 167, 69);
                case "activated":
                    return Color.FromRgb(108, 117, 125);
                case "expired":
                    return Color.FromRgb(0, 123, 255);
                default:
                    return Color.FromRgb(108, 117, 125);
            }
        }

        private void HandleProductAction(UserProduct product)
        {
            switch (product.activation_status?.ToLower())
            {
                case "pending":
                    ActivateProduct(product);
                    break;
                case "expired":
                    // Открываем сайт для продления
                    System.Diagnostics.Process.Start("http://195.133.25.152:7777/taskflow.app");
                    break;
                case "activated":
                    // Показываем сообщение
                    ShowSuccess("Продукт уже активирован");
                    break;
            }
        }

        private void ActivateProduct(UserProduct product)
        {
            _activatedProduct = product;
            SaveActivatedProduct();
            UpdateUserStatusIndicator();
            UpdateSubscriptionStatusBlock();
            ShowSuccess($"Продукт {GetProductDisplayName(product.product_name)} успешно активирован!");
        }

        private void CreateSubscriptionStatusBlock(StackPanel parentPanel)
        {
            var statusBorder = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(248, 249, 250)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(222, 226, 230)),
                BorderThickness = new Thickness(1),
                Margin = new Thickness(0, 40, 0, 0),
                Padding = new Thickness(20)
            };

            var statusPanel = new StackPanel();
            
            var statusTitle = new TextBlock
            {
                Text = "Состояние подписки плагина",
                FontSize = 18,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 15),
                Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
            };
            statusPanel.Children.Add(statusTitle);

            var activatedProductBlock = new StackPanel { Name = "ActivatedProductBlock" };
            statusPanel.Children.Add(activatedProductBlock);

            statusBorder.Child = statusPanel;
            parentPanel.Children.Add(statusBorder);

            // Загружаем активированный продукт и обновляем блок
            LoadActivatedProduct();
            UpdateSubscriptionStatusBlock();
        }

        private void UpdateSubscriptionStatusBlock()
        {
            var activatedProductBlock = FindName("ActivatedProductBlock") as StackPanel;
            if (activatedProductBlock == null) return;

            activatedProductBlock.Children.Clear();

            if (_activatedProduct != null)
            {
                var productInfo = new StackPanel();
                
                var productName = new TextBlock
                {
                    Text = $"Активированный продукт: {GetProductDisplayName(_activatedProduct.product_name)}",
                    FontSize = 16,
                    FontWeight = FontWeights.SemiBold,
                    Margin = new Thickness(0, 0, 0, 10),
                    Foreground = new SolidColorBrush(Color.FromRgb(40, 167, 69))
                };
                productInfo.Children.Add(productName);

                var status = new TextBlock
                {
                    Text = $"Статус: {GetStatusDisplayText(_activatedProduct.activation_status)}",
                    FontSize = 14,
                    Margin = new Thickness(0, 0, 0, 5),
                    Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
                };
                productInfo.Children.Add(status);

                var expires = new TextBlock
                {
                    Text = $"Истекает: {_activatedProduct.expires_at?.ToString("dd.MM.yyyy") ?? "Не указано"}",
                    FontSize = 14,
                    Margin = new Thickness(0, 0, 0, 15),
                    Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125))
                };
                productInfo.Children.Add(expires);

                var deactivateButton = new Button
                {
                    Content = "Деактивировать",
                    FontSize = 14,
                    Height = 35,
                    Width = 120,
                    Background = new SolidColorBrush(Color.FromRgb(220, 53, 69)),
                    Foreground = Brushes.White,
                    BorderThickness = new Thickness(0)
                };
                deactivateButton.Click += (s, e) => DeactivateProduct();
                productInfo.Children.Add(deactivateButton);

                activatedProductBlock.Children.Add(productInfo);
            }
            else
            {
                var noProductText = new TextBlock
                {
                    Text = "Нет активированных продуктов. Активируйте продукт из списка выше.",
                    FontSize = 14,
                    Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125)),
                    TextWrapping = TextWrapping.Wrap
                };
                activatedProductBlock.Children.Add(noProductText);
            }
        }

        private void DeactivateProduct()
        {
            _activatedProduct = null;
            SaveActivatedProduct();
            UpdateUserStatusIndicator();
            UpdateSubscriptionStatusBlock();
            ShowSuccess("Продукт деактивирован");
        }

        private void LoadProfileEditForm(StackPanel parentPanel)
        {
            var title = new TextBlock
            {
                Text = "Управление профилем",
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 30),
                Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
            };
            parentPanel.Children.Add(title);

            var placeholderText = new TextBlock
            {
                Text = "Функция редактирования профиля будет добавлена в следующих версиях",
                FontSize = 16,
                Foreground = new SolidColorBrush(Color.FromRgb(108, 117, 125)),
                Margin = new Thickness(0, 20, 0, 0)
            };
            parentPanel.Children.Add(placeholderText);
        }

        private void LoadAuthManagement(StackPanel parentPanel)
        {
            var title = new TextBlock
            {
                Text = "Управление аккаунтом",
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0, 0, 0, 30),
                Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
            };
            parentPanel.Children.Add(title);

            if (_currentUser != null)
            {
                var userInfo = new TextBlock
                {
                    Text = $"Вы вошли как: {_currentUser.Name} ({_currentUser.Email})",
                    FontSize = 16,
                    Margin = new Thickness(0, 0, 0, 30),
                    Foreground = new SolidColorBrush(Color.FromRgb(33, 37, 41))
                };
                parentPanel.Children.Add(userInfo);
            }

            var buttonPanel = new StackPanel { Orientation = Orientation.Horizontal };

            var websiteButton = new Button
            {
                Content = "🌐 Перейти на сайт",
                FontSize = 14,
                Height = 40,
                Width = 150,
                Margin = new Thickness(0, 0, 15, 0),
                Background = new SolidColorBrush(Color.FromRgb(0, 123, 255)),
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0)
            };
            websiteButton.Click += (s, e) => System.Diagnostics.Process.Start("http://195.133.25.152:7777/taskflow.app");
            buttonPanel.Children.Add(websiteButton);

            var logoutButton = new Button
            {
                Content = "🚪 Выйти из аккаунта",
                FontSize = 14,
                Height = 40,
                Width = 150,
                Background = new SolidColorBrush(Color.FromRgb(220, 53, 69)),
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0)
            };
            logoutButton.Click += (s, e) => Logout();
            buttonPanel.Children.Add(logoutButton);

            parentPanel.Children.Add(buttonPanel);
        }

        private void Logout()
        {
            _authService.ClearToken();
            _currentUser = null;
            _activatedProduct = null;
            ShowAuthScreen();
            ShowSuccess("Вы успешно вышли из системы");
        }

        private void SaveActivatedProduct()
        {
            try
            {
                var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                var civilXPath = Path.Combine(appDataPath, "CivilX", "AuthPlugin");
                Directory.CreateDirectory(civilXPath);
                var filePath = Path.Combine(civilXPath, "activated_product.json");

                if (_activatedProduct != null)
                {
                    var json = new JavaScriptSerializer().Serialize(_activatedProduct);
                    File.WriteAllText(filePath, json);
                }
                else
                {
                    if (File.Exists(filePath))
                    {
                        File.Delete(filePath);
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка сохранения активированного продукта: {ex.Message}");
            }
        }

        private void LoadActivatedProduct()
        {
            try
            {
                var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                var civilXPath = Path.Combine(appDataPath, "CivilX", "AuthPlugin");
                var filePath = Path.Combine(civilXPath, "activated_product.json");

                if (File.Exists(filePath))
                {
                    var json = File.ReadAllText(filePath);
                    _activatedProduct = new JavaScriptSerializer().Deserialize<UserProduct>(json);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка загрузки активированного продукта: {ex.Message}");
                _activatedProduct = null;
            }
        }

        private void UpdateUserStatusIndicator()
        {
            // Обновляем индикатор статуса пользователя
            if (_authService != null)
            {
                var token = _authService.GetStoredToken();
                if (string.IsNullOrEmpty(token))
                {
                    // Пользователь не авторизован - прозрачный фон
                    SetUserIcon("👤", Colors.Transparent);
                }
                else if (_activatedProduct != null)
                {
                    // Продукт активирован - зеленый фон
                    SetUserIcon("👤", Colors.Green);
                }
                else
                {
                    // Пользователь авторизован, но продукт не активирован - красный фон
                    SetUserIcon("👤", Colors.Red);
                }
            }
        }

        private void SetUserIcon(string icon, Color backgroundColor)
        {
            // Этот метод будет обновлять иконку пользователя в интерфейсе
            // Пока что просто логируем
            System.Diagnostics.Debug.WriteLine($"User icon: {icon}, Background: {backgroundColor}");
        }

        private void ShowError(string message)
        {
            ErrorMessage.Text = message;
            ErrorMessage.Visibility = Visibility.Visible;
            SuccessMessage.Visibility = Visibility.Collapsed;
        }

        private void ShowSuccess(string message)
        {
            SuccessMessage.Text = message;
            SuccessMessage.Visibility = Visibility.Visible;
            ErrorMessage.Visibility = Visibility.Collapsed;
        }

        private void HideMessages()
        {
            ErrorMessage.Visibility = Visibility.Collapsed;
            SuccessMessage.Visibility = Visibility.Collapsed;
        }

        // Обработчики событий для полей ввода
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox != null && textBox.Text == textBox.Name.Replace("Register", "").Replace("Login", ""))
            {
                textBox.Text = "";
                textBox.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox != null && string.IsNullOrEmpty(textBox.Text))
            {
                textBox.Text = textBox.Name.Replace("Register", "").Replace("Login", "");
                textBox.Foreground = new SolidColorBrush(Color.FromRgb(156, 163, 175));
            }
        }

        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var passwordBox = sender as PasswordBox;
            if (passwordBox != null && passwordBox.Password == "Пароль" || passwordBox.Password == "Подтвердите пароль")
            {
                passwordBox.Password = "";
                passwordBox.Foreground = new SolidColorBrush(Color.FromRgb(255, 255, 255));
            }
        }

        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var passwordBox = sender as PasswordBox;
            if (passwordBox != null && string.IsNullOrEmpty(passwordBox.Password))
            {
                passwordBox.Password = passwordBox.Name.Contains("Confirm") ? "Подтвердите пароль" : "Пароль";
                passwordBox.Foreground = new SolidColorBrush(Color.FromRgb(156, 163, 175));
            }
        }
    }
}
