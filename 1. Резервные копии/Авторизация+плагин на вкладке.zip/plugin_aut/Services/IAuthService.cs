using System;
using System.Threading.Tasks;

namespace CivilXAuthPlugin.Services
{
    public interface IAuthService
    {
        Task<AuthResult> LoginAsync(string email, string password);
        Task<AuthResult> RegisterAsync(string userType, string name, string login, string email, string password);
        Task<UserInfo> GetUserInfoAsync(string token);
        Task<bool> ValidateTokenAsync(string token);
        string GetStoredToken();
        void SaveToken(string token);
        void ClearToken();
    }

}

